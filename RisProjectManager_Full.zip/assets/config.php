<?php
$webName = '瑞思项目管理';
$adminPassword = '$2y$10$k58VWPYgm8/prQpMkYUPgeMrA4xEeiZ1QcorxtzsdcVgA3NCimuBa';

$copyRight = '版权所有 © 2024 腾瑞思智';
$securityEntrance = '';
